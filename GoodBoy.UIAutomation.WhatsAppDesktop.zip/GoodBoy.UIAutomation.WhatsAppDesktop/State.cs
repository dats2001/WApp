﻿namespace GoodBoy.UIAutomation.WhatsAppDesktop {
	public enum State {
		NotStarted,
		NeedLogin,
		Ready,
		Calling,
		NotInWhatsApp
	}
}
