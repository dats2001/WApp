﻿using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Automation;

using static System.Net.Mime.MediaTypeNames;

namespace GoodBoy.UIAutomation.WhatsAppDesktop {
	public class WhatsAppDesktop : Automated, IWhatsAppDesktop {
		public bool LoggedIn { get; set; }

		private Stopwatch _stopwatch = new Stopwatch();

		private string _currentPhone;
		private string _currentCallStatusText;
		private string _popupBoxText;
		private bool _handledPopup;

		public State CurrentState { get; set; } = State.NotStarted;

		public event EventHandler<WhatsAppEventArgs> NotInWhatsApp;
		public event EventHandler<WhatsAppEventArgs> WhatsAppStarted;
		public event EventHandler<WhatsAppEventArgs> Busy;
		public event EventHandler<WhatsAppEventArgs> CallStart;
		public event EventHandler<WhatsAppEventArgs> CallEnd;
		public event EventHandler<WhatsAppEventArgs> CallStatusTextChanged;
		public event EventHandler<WhatsAppEventArgs> PopupBox;
		public event EventHandler<WhatsAppEventArgs> Exception;
		public event EventHandler<WhatsAppEventArgs> StateChanged;

		#region Automation Elements

		private AutomationElement _voiceCallWindow;
		private AutomationElement _callStatusText;
		private WhatsAppPopup _popupBox;

		#endregion

		private object _lock = new object();

		public WhatsAppDesktop() {
			StartApp("whatsapp://app", "WhatsApp");
			Thread.Sleep(2000);
			CurrentState = State.Ready;
			WhatsAppStarted?.Invoke(this, new WhatsAppEventArgs("whatsapp started"));

			var _popupBoxHandlerTask = Task.Run(() => {
				while (true) {
					if (TryHandleWhatsAppPopupElement(out var _popupElement)) {
						_popupBox = /*_popupBox ??*/ new WhatsAppPopup(_popupElement);
						_popupBoxText = _popupBox.Text;

						if (_popupBoxText != null) {
							if (_popupBoxText.Contains("не зарегистрирован")) {
								CurrentState = State.NotInWhatsApp;
								StateChanged?.Invoke(this, new WhatsAppEventArgs($"StateChanged: {CurrentState}"));
								NotInWhatsApp?.Invoke(this, new WhatsAppEventArgs($"NotInWhatsApp: {_currentPhone}"));
							}

							PopupBox?.Invoke(this, new WhatsAppEventArgs($"PopupBox: {_popupBoxText}"));
							_popupBox.Ok();
						}										
					}
					try {
						Thread.Sleep(100);
					}
					catch { }
				}
			});

			var _callStatusTextHandlerTask = Task.Run(() => { 
				while (true) {
					if (CurrentState == State.Calling) {
						_callStatusText = AutomationElement.RootElement
							.FindFirst(TreeScope.Descendants, new PropertyCondition(AutomationElement.AutomationIdProperty, Settings.WhatsAppUI.Ru.CallStatusTextId));

						if (_callStatusText != null && _currentCallStatusText != _callStatusText?.Current.Name) {
							_currentCallStatusText = _callStatusText?.Current.Name;
							CallStatusTextChanged?.Invoke(this, new WhatsAppEventArgs($"CallStatusTextChanged: {_currentCallStatusText}"));

							if (_currentCallStatusText.Contains(Settings.WhatsAppUI.Ru.CallEndStatusText)) {
								CurrentState = State.Ready;
								StateChanged?.Invoke(this, new WhatsAppEventArgs($"StateChanged: {CurrentState}"));
								CallEnd?.Invoke(this, new WhatsAppEventArgs($"CallEnd: {_currentPhone}"));
							}
						}
					}					

					try {
						Thread.Sleep(30);
					}
					catch { }
				}
			});

			var _handleVoiceCallWindowTask = Task.Run(() => {

			});
		}

		public void NewChat() => PushButton(Settings.WhatsAppUI.Ru.NewChatButton);

		public void Call(string phone, int timeoutInMs = 5000) {
			CurrentState = State.Calling;

			StateChanged?.Invoke(this, new WhatsAppEventArgs($"StateChanged: {CurrentState}"));

			_currentCallStatusText = string.Empty;
			_currentPhone = phone;

			CallStart?.Invoke(this, new WhatsAppEventArgs($"CallStart: {_currentPhone}"));

			_ = Process.Start($"whatsapp://send?phone={phone}");
			Thread.Sleep(1000);

			if (CurrentState == State.NotInWhatsApp) {
				CurrentState = State.Ready;
				StateChanged?.Invoke(this, new WhatsAppEventArgs($"StateChanged: {CurrentState}"));

				return;
			}

			PushButton(Settings.WhatsAppUI.Ru.VoiceCallButton);
		}

		public void Dispose() => QuitApp();

		public void PressButton(string buttonName) => PushButton(buttonName);

		public void Login() {
			PushButton(Settings.WhatsAppUI.Ru.GetStarted);
			Thread.Sleep(1000);

			var qrImage = _root.FindFirst(TreeScope.Children | TreeScope.Descendants, new PropertyCondition(AutomationElement.AutomationIdProperty, "QrImage"));

		}

		private (bool handled, WhatsAppPopup popupBox) TryGetWhatsAppPopup() {
			var _popup = _root.FindFirst(TreeScope.Descendants, new PropertyCondition(AutomationElement.NameProperty, Settings.WhatsAppUI.Ru.PopupBoxName));

			if (_popup != null) {
				var popup = new WhatsAppPopup(_popup);							

				return (true, popup);
			}
			else {
				return (false, null);
			}
		}

		private bool TryHandleWhatsAppPopupElement(out AutomationElement popupElement) {
			popupElement = _root.FindFirst(TreeScope.Descendants, new PropertyCondition(AutomationElement.NameProperty, Settings.WhatsAppUI.Ru.PopupBoxName));
			return popupElement != null;			
		}
	}
}
