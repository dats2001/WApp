﻿using System;

namespace GoodBoy.UIAutomation.WhatsAppDesktop {
	public class WhatsAppEventArgs : EventArgs {
		private string _message;
		public string Message => _message;

		public WhatsAppEventArgs(string message) {
			_message = message;
		}
	}
}