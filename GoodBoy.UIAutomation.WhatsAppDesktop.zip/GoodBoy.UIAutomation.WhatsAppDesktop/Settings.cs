﻿namespace GoodBoy.UIAutomation.WhatsAppDesktop {
	public static class Settings {
		public static class GlobalSettings {
			public static string Language = "RU";
		}

		public static class WhatsAppUI {
			public static class Ru {
				public static string NewChatButton = "NewConvoButton";
				public static string VoiceCallButton = "Аудиозвонок";
				public static string QueryTextBox = "QueryTextBox";
				public static string GetStarted = "Начать";
				public static string QrImage = "QrImage";
				public static string Settings = "Открыть Настройки";
				public static string LogOut = "Выйти";
				public static string Yes = "Да";
				public static string Ok = "ОК"; 
				public static string VoiceCallTitle = "Аудиозвонок - WhatsApp";
				public static string Calling = "Соединение...";
				public static string CallStatusTextId = "CallStatusText";
				public static string PopupBoxName = "Всплывающее окно";
				public static string PopupBoxTextId = "Message";
				public static string CallEndStatusText = "Звонок завершён";
			}
		}

		public static class SIPConstants {
			public const string SIP_DEFAULT_USERNAME = "Nikita";
			public const string SIP_DEFAULT_FROMURI = "sip:from_code@goodboy";
			public const string SDP_MIME_CONTENTTYPE = "application/sdp";
			public const ushort DEFAULT_SIP_PORT = 5060;
		}
	}
}
