﻿using System;
using System.Windows.Automation;
using System.Xml.Linq;

namespace GoodBoy.UIAutomation.WhatsAppDesktop {
	public class WhatsAppPopup : Automated {
		public string Text {
			get { 
				var _textBox = _root?.FindFirst(TreeScope.Descendants, new PropertyCondition(AutomationElement.AutomationIdProperty, Settings.WhatsAppUI.Ru.PopupBoxTextId));
				return _textBox?.Current.Name;
			}  
		}

		public WhatsAppPopup(AutomationElement popupRoot) => _root = popupRoot;

		public void Ok() {
			var button = _root.FindFirst(TreeScope.Descendants, new PropertyCondition(AutomationElement.NameProperty, Settings.WhatsAppUI.Ru.Ok));
			if (button != null) {
				GetInvokePattern(button).Invoke();
			}
		}
	}
}