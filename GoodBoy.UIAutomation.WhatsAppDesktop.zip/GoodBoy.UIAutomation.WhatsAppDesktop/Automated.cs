﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Windows.Automation;
using System.Windows.Forms;
using System.Xml.Linq;

namespace GoodBoy.UIAutomation.WhatsAppDesktop {
	public class Automated {
		protected Process _process;
		protected AutomationElement _root;
		private Dictionary<string, AutomationElement> _elements = new Dictionary<string, AutomationElement>();
		private Stopwatch _stopwatch = new Stopwatch();

		protected void StartApp(string appName, string rootElement, int timeoutInMs = 7000) {
			_process = Process.Start(appName);
			//_stopwatch.Reset();
			//_stopwatch.Start();

			do {
				_root = AutomationElement.RootElement
					.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, rootElement));
				Thread.Sleep(100);
			}
			while (_root == null && _stopwatch.ElapsedMilliseconds < timeoutInMs);

			//var newChat = _root.FindFirst(TreeScope.Subtree, new PropertyCondition(AutomationElement.NameProperty, "Новый чат"));
			//PushButton("Новый чат");


			var searchTextBox = _root.FindFirst(TreeScope.Subtree, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Edit));


			object valuePattern = null;
			//if (!searchTextBox.TryGetCurrentPattern(ValuePattern.Pattern, out valuePattern)) {
				// Set focus for input functionality and begin.
			//	searchTextBox.SetFocus();

				// Pause before sending keyboard input.
				Thread.Sleep(100);

				// Delete existing content in the control and insert new content.
				//SendKeys.SendWait("^{HOME}");   // Move to start of control
				//SendKeys.SendWait("^+{END}");   // Select everything
				//SendKeys.SendWait("{DEL}");     // Delete selection
				

			//}
			//else {

			//	((ValuePattern)valuePattern).SetValue("+79119115650");
			//	 SendKeys.SendWait(" ");
			//}




				if (_root == null) {
				throw new TimeoutException(appName + " could not be started");
			}
		}

		protected void QuitApp() {
			if (_process != null) {
				_process.CloseMainWindow();
				_process.Dispose();
			}
		}

		protected void PushButton(string name) => GetInvokePattern(GetButton(name)).Invoke();

		protected bool IsEnabled(AutomationElement element) => (bool)element.GetCurrentPropertyValue(AutomationElement.IsEnabledProperty);

		protected void WaitEnabled(AutomationElement element, int timeoutInMs) {
			_stopwatch.Reset();
			_stopwatch.Start();

			while (!IsEnabled(element) && _stopwatch.ElapsedMilliseconds < timeoutInMs) {
				Thread.Sleep(10);
			}

			_stopwatch.Stop();

			if (!IsEnabled(element)) {
				throw new TimeoutException("Timed out when waiting the element to get enabled.");
			}
		}

		protected InvokePattern GetInvokePattern(AutomationElement element) {
			WaitEnabled(element, 1000);

			return element.GetCurrentPattern(InvokePattern.Pattern) as InvokePattern;
		}

		protected AutomationElement GetButton(string name) {
			if (_elements.TryGetValue(name, out AutomationElement elem)) {
				return elem;
			}

			var result = _root.FindFirst(TreeScope.Descendants, new PropertyCondition(AutomationElement.NameProperty, name));

			if (result == null) {
				throw new ArgumentException("No function button found with name: " + name);
			}

			_elements.Add(name, result);

			return result;
		}
	}
}
