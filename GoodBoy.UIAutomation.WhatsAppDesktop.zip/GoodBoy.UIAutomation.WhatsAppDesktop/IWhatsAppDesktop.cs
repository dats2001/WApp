﻿using System;

namespace GoodBoy.UIAutomation.WhatsAppDesktop {
	public interface IWhatsAppDesktop : IDisposable {
		void Login();
		void NewChat();
		void Call(string phone, int timeoutInMs = 10000);
	}
}
